#pragma once

#include <ESP8266WiFi.h>
#include <DNSServer.h>
#include <ESP8266WebServer.h>
#include <WiFiManager.h>          //https://github.com/tzapu/WiFiManager
#include <vector>
#include <iostream>
#include <string>
#include <utility>
#include <stdexcept>
#include <map>
#include <ArduinoJson.h>              // Verarbeitung JSON Daten
//#include "FS.h"                       // Verwaltung SPIFFS

#include "definitions.h"
#include "webconfig.h"

class Settings {
private:
  
public:
  std::string wifiSSID;
  std::string wifiPassword;
  std::string mqttServer;
  std::string mqttUser;
  std::string mqttPassword;
  std::string mqttClientName;
  std::string mqttPubTopic;
  std::string mqttSubTopic;
  int mqttServerPort;
  int keypadDebounceTime;
  int keypadRepeatDelay;
  int keypadRepeatInterval;
  int keypadRepeatMask;
  int keypadMultikeyTimeout;
  int keypadMultikeyMask;
  int keypadAPKeyMask;
  int keypadAPKeyTime;
};

extern WiFiManager wifiManager;


void settingsDefault(Settings &settings);
void loadSettings(fs::FS &fs, const char * path, Settings &settings);
void saveSettings(fs::FS &fs, const char * path, Settings &settings);
void importSettings(std::string & jsonSettings, Settings &settings);
WiFiManager buildConfigAP(Settings &settings);
void openSettingsWebConfig (Settings &settings, uint8_t * webConfigResult, int timeout=-1);
std::string getJsonFromWebConfig ();
void updateSettingsWebPortal();
