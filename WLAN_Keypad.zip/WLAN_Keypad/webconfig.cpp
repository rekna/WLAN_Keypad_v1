#include "webconfig.h"

ESP8266WebServer server(80); //Server on port 80

extern WebConfigPortal webConfigPortal;

const char* MDNSName="ESP8266";

const char html_start[] = "<!DOCTYPE HTML><html>@@HEAD@@BODY</html>";
const char html_head[] = "<title>@@TITLE</title><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width, initial-scale=1, maximus-scale = 1, user-scalable=0\">@@STYLES";
const char html_body[] = "<body><form id=\"esporm\" action=\"/action\" method=\"post\">@@FORMDATA</form></body>";
const char html_form_buttons_table[] = "<tr><td><input type=\"submit\" name=\"action\" value=\"save\"></td><td><input type=\"submit\" name=\"action\" value=\"cancel\"></td></tr>";
//const char html_form_buttons_table2[] = "<tr><td><button form=\"espform\" type=\"submit\" name=\"save\" value=\"1\">Save</button></td><td><button form=\"espform\" type=\"submit\" name=\"cancel\" value=\"1\">Cancel</button></td></tr>";
const char html_save[] = "<html><body><p>Settings saved</p></body></html>";
const char html_cancel[] = "<html><body><p>Webform canceled</p></body></html>";

void handleRootWrapper () {
  webConfigPortal.handleRoot();
}

void handleActionWrapper () {
  webConfigPortal.handleAction();
}

WebConfigPortal::WebConfigPortal() {
  uint8_t mac[6];
  std::string macStr=WiFi.macAddress().c_str();
  Serial.print ("ESP MAC Address: ");
  Serial.println (WiFi.macAddress());
  int pos=macStr.find(":", 0);
  while (pos!=std::string::npos) {
    macStr.erase(pos,1);
    pos=macStr.find(":", 0);
  }
  std::string apName="ESPWebConfig_"+macStr.substr(8);
  /*
  for (int i = 0; i < 6; ++i) {
    Serial.print (":");
    Serial.print(std::string(mac[i], 16).c_str());
  }
  Serial.println ();
  //*/
  this->_apSSID = apName; 
//+std::string(mac[4], 16)+std::string(mac[5], 16);
  Serial.println (_apSSID.c_str());
  this->_apPassword = "password00";
  this->_htmlConfigPage="";
  this->_itemStore=NULL;
  this->_actionResult = NULL;
  this->_webConfigStartTime=0;
  this->_webConfigTimeout=-1;
  this->_htmlTitle="ESP Web Config";
  this->_htmlMessage="ESP Configuration:";
  this->_webConfigTimeout=-1;
  this->_ip.fromString("192.168.4.1");
  this->_gw.fromString("192.168.4.1");
  this->_nm.fromString("255.255.255.0");
  this->_dns1.fromString("192.168.4.1");
  this->_dns2.fromString("192.168.4.1");
}

void WebConfigPortal::myReplace(std::string & myString, const std::string & searchPattern, const std::string & replaceStr) {
  myString.replace (myString.find(searchPattern),searchPattern.size(), replaceStr);
}

std::string WebConfigPortal::generateHtmlInputField (const std::string & inputLabel, const std::string & inputName, const std::string & inputPlaceholder, const std::string & inputValue, const int & len, const std::string regEx) {
  std::string result="<tr><td>";
  result += "<label for=\""+inputName+"\">"+inputLabel+"</label>";
  result += "</td><td>";
  char buf[50];
  itoa(len, buf, 10);
  std::string lenStr=std::string(buf);
  result += "<input type=\"text\" name=\""+inputName+"\" placeholder=\""+inputPlaceholder+"\" value=\""+inputValue+"\" maxlength=\""+lenStr+"\"";
  if (regEx!="")
    result += " pattern=\""+regEx+"\"";
  result += ">";
  result += "</td></tr>";
  return result; 
}

std::string WebConfigPortal::buildWebForm() {
  std::string htmlPage=std::string(html_start);

  std::string pattern="";
  
  // Build Head
  std::string htmlHead=std::string(html_head);
  std::string styles="<style>";
  styles += "label { cursor: default; padding-top: 10px}";
  styles += "</style>";
  pattern="@@TITLE";
  myReplace (htmlHead, "@@TITLE", this->_htmlTitle);
  myReplace (htmlHead, "@@STYLES", styles);
  
  myReplace (htmlPage, "@@HEAD", htmlHead);
  
  // Build Body
  if (this->_itemStore!=NULL) {
    std::string table;
    if (_htmlMessage!="")
      table += "<p>"+_htmlMessage+"</p>";
    table += "<table>";
    //table += generateHtmlInputField ("Label", "myInput", "Tippe hier", "", 5);
    for (auto item: *_itemStore) {
      table += generateHtmlInputField (item.label, item.name, item.placeholder, item.value, item.len, item.regExPattern);
    }
    table += std::string (html_form_buttons_table);
    table +="</table>";
    //std::string table=<tr><td>1</td><td>2</td></tr></table>";
    std::string body=std::string (html_body);
    myReplace (body, "@@FORMDATA", table);
  
    myReplace (htmlPage, "@@BODY", body);
  } else {
    myReplace (htmlPage, "@@BODY", std::string ("<p>No form data exists</p>"));
  }
  
  return htmlPage;
}

void WebConfigPortal::handleRoot () {
  _webConfigStartTime=millis();
  server.send (200, "text/html", _htmlConfigPage.c_str());
}

int WebConfigPortal::findWebItemIndex (std::string itemName) {
  int cnt=0;
  for (auto item: *_itemStore) {
    if (item.name == itemName)
      return cnt;
    cnt++;
  }
  return -1;
}

void WebConfigPortal::handleAction () {
  if (server.args()!=0) {
    if (server.hasArg("action")) {
      if (server.arg("action")=="save") {
        if (_actionResult!=NULL) *_actionResult=1;
        int cnt=0;
        while (cnt<server.args()) {
          std::string argName=std::string (server.argName(cnt).c_str());
          std::string argValue=std::string (server.arg(cnt).c_str());
          if ((argName!="plain")&&(argName!="action")) {
            int itemPos=findWebItemIndex(argName);
            if (itemPos>=0)
              _itemStore->at(itemPos).value=argValue;
          }
          cnt++;
        } 
      } else if (server.arg("action")=="cancel") {
          if (_actionResult!=NULL) *_actionResult=2;
      }
    }
  }
  Serial.println ("Action");
  delay (2000);
  //_htmlConfigPage=buildWebForm();
  if (_actionResult!=NULL) {
    if (*_actionResult!=0) {
      if (*_actionResult==1)
        server.send (200, "text/html", html_save);
      else
        server.send (200, "text/html", html_cancel);
      delay(2000);
      stopConfigPortal();
    } else 
      server.send (200, "text/html", _htmlConfigPage.c_str());
  } else server.send (200, "text/html", _htmlConfigPage.c_str());
}

void WebConfigPortal::startConfigPortal()
{
  /*
  _itemStore = itemStore;
  _actionResult = actionFlag;
  *_actionResult = 0;
  *
   */

  _htmlConfigPage=buildWebForm();

  // Action Flag zurücksetzen
  if (_actionResult!=NULL)
    *_actionResult=0;
  
  // AP aufmachen
  //if (WiFi.status() != WL_CONNECTED) {
  WiFi.persistent(false);
  WiFi.mode(WIFI_AP);
  if (_apPassword=="") 
    WiFi.softAP(_apSSID.c_str()); 
  else
    WiFi.softAP(_apSSID.c_str(), _apPassword.c_str()); 
  WiFi.config(_ip, _gw, _nm, _dns1, _dns2);
  IPAddress myIP =WiFi.softAPIP();

  Serial.print (_apSSID.c_str());
  Serial.print (" - ");
  Serial.println (myIP);

  server.on("/", handleRootWrapper);
  server.on("/action", handleActionWrapper);

/*
  if (mdns.begin("esp8266WebForm", WiFi.localIP())) {
    Serial.println("MDNS responder started");
  }
*/

  Serial.print("Connect to http://esp8266WebForm.local or http://");
  Serial.println(WiFi.localIP());

  server.begin();
  _webConfigStartTime=millis();
}

void WebConfigPortal::stopConfigPortal () {
  _webConfigStartTime=0;
  //if (_actionResult!=NULL) *_actionResult=3;       // Aufrufenden Task benachrichtigen
  server.close();
  server.stop();
  WiFi.persistent(false);
  WiFi.mode(WIFI_STA);
}

void WebConfigPortal::updateConfigPortal() {
  static uint32_t updateTimestamp=0;
  if (_webConfigStartTime==0) return;
  server.handleClient();
  uint32_t now=millis();
  if (now-updateTimestamp>=1000) {
    updateTimestamp=now;
    //Serial.print ("Actionresult: ");
    //Serial.println (*_actionResult);
    // Webconfig Timeout nur, wenn noch kein anderes Ende stattfand
    if ((_webConfigTimeout>=0)&&((_actionResult!=NULL)&&(*_actionResult==0))) {
      uint32_t passedTime=now-_webConfigStartTime;
      /*
      Serial.print ("Time passed: ");
      Serial.print (passedTime);
      Serial.print (" / ");
      Serial.println (_webConfigTimeout*1000);
      */
      if (passedTime>=_webConfigTimeout*1000) {
        if (_actionResult!=NULL) *_actionResult=3;       // Aufrufenden Task benachrichtigen
        Serial.println ("WebServer Timeout");
        stopConfigPortal();
        Serial.println ("WebServer stopped");
      }
    }
  }
}


void WebConfigPortal::setAP(std::string ssid, std::string password) {
  this->_apSSID = ssid;
  this->_apPassword = password;
}

void WebConfigPortal::setTitle (std::string newTitle) {
  this->_htmlTitle = newTitle;
}

void WebConfigPortal::setItemStore (std::vector<WebConfigItem> * itemStore) {
  this->_itemStore = itemStore;
}

void WebConfigPortal::setActionFlag (uint8_t * actionFlag) {
  this->_actionResult=actionFlag;
}

void WebConfigPortal::setTimeout (int timeout) {
  this->_webConfigTimeout=timeout;
}
