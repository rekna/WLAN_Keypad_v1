#include "settings.h"

std::vector<WebConfigItem> _webConfigItems;
WebConfigPortal webConfigPortal;


// IP Adresse ausgeben
void printIP (uint8_t * ipAdr) {
  char buf[50];
  sprintf(buf,"IP: %03d.%03d.%03d.%03d\r\n",ipAdr[0],ipAdr[1],ipAdr[2],ipAdr[3]);
  Serial.print (buf);
}

void stripIp (std::string str, uint8_t * ipAdr) {
  uint32_t ipMask=0;
  // Ist delimiter / für Subnetz drinnen? => Subnetzmaske bilden
  size_t strPos=str.find(IPDELIMSUBNET,0);
  if (strPos!=std::string::npos) {
    std::string tmp=str.substr(strPos+1);
    int bits=atoi(tmp.c_str());
    for (uint8_t i=0; i<min(32,bits); i++) {
      ipMask|=(1<<i);
    }
    ipAdr[0]==(ipMask>>24)&0xff;
    ipAdr[1]==(ipMask>>16)&0xff;
    ipAdr[2]==(ipMask>>8)&0xff;
    ipAdr[3]==ipMask&0xff;
  } else {
    // Einzelne IP Werte bestimmen
    int ndx=0;
    int lpos=0;
    int pos=str.find(IPDELIM,lpos);
    while (ndx<4) {
      std::string tmp=str.substr(lpos,pos-lpos);
      // Wert auslesen und abspeichern
      ipAdr[ndx]=atoi(tmp.c_str());
      ndx++;
      if (pos==std::string::npos) break;
      lpos=pos+1;
      pos=str.find(IPDELIM,lpos);
    }
  }
  //printIP(ipAdr);
}

// MAC zu String für automatischen Namen
std::string macToStr(const uint8_t* mac)
{
  std::string result;
  for (int i = 0; i < 6; ++i) {
    result += std::string(mac[i], 16);
    if (i < 5)
      result += ':';
  }
  return result;
}

// Liest JSON String aus, wenn vorhanden, sonst default
void getJsonString (JsonObject &doc, std::string key, std::string &destination, std::string defaultValue) {
  if (doc.containsKey(key.c_str())) destination=std::string(doc[key.c_str()].as<char*>());
  else destination=defaultValue;
  /*
  Serial.print ("Setting: ");
  Serial.print (key.c_str());
  Serial.print (" - Value: ");
  Serial.println (destination.c_str());
  */
}

// Liest JSON Int aus, wenn vorhandne, sonst default
void getJsonInt (JsonObject &doc, std::string key, int &destination, int defaultValue) {
  // Wert vorhanden?
  if (!doc.containsKey(key.c_str())) {
    destination=defaultValue;
    return;
  }
  if (doc[key.c_str()].is<char*>()||doc[key.c_str()].is<const char*>()) {
    // Wert ist String?
    std::string tempStr=std::string(doc[key.c_str()].as<char*>());
    if (tempStr == "") {
      destination=defaultValue;
      return;
    }
    if (tempStr.find ("0x")==0) {   // HEX?
      //Serial.println ("HEX Zahl: ");
      //Serial.println (tempStr.c_str());
      destination=std::strtol(tempStr.c_str(), NULL, 16);
    } else if (tempStr.find ("0")==0) {// Octal
      //Serial.println ("OCT Zahl: ");
      //Serial.println (tempStr.c_str());
      destination=std::strtol(tempStr.c_str(), NULL, 8);
    } else { // Default dezimal
      //Serial.println ("DEC Zahl: ");
      //Serial.println (tempStr.c_str());
      destination=std::strtol(tempStr.c_str(), NULL, 10);
    }
  } else {
    // Wenn nicht, dann Integer annehmen
    destination=doc[key.c_str()];
  }
  /*
  if (  (doc.is<int>(key.c_str())) ||
        (doc.is<short>(key.c_str())) ||
        (doc.is<long>(key.c_str())) ||
        (doc.is<long long>(key.c_str()))
     ) {
      destination=doc[key.c_str()];
  } else
  if ((doc.is<const char*>(key.c_str()))||(doc.is<char*>(key.c_str()))) { // Wert als String auslesen
    std::string tempStr=std::string(doc[key.c_str()].as<char*>());
    if (tempStr == "") {
      destination=defaultValue;
      return;
    }
    if (tempStr.find ("0x")==0) {   // HEX?
      Serial.println ("HEX Zahl: ");
      Serial.println (tempStr.c_str());
      //destination=std::strtol(tempStr.c_str(), NULL, 16);
    } else if (tempStr.find ("0")==0) {// Octal
      Serial.println ("OCT Zahl: ");
      Serial.println (tempStr.c_str());
      //destination=std::strtol(tempStr.c_str(), NULL, 8);
    } else { // Default dezimal
      Serial.println ("DEC Zahl: ");
      Serial.println (tempStr.c_str());
      //destination=std::strtol(tempStr.c_str(), NULL, 10);
    }
  }
  */
  /*
  Serial.print ("Setting: ");
  Serial.print (key.c_str());
  Serial.print (" - Value: ");
  Serial.println (destination);
  */
}

// Liest Einstellungen aus JSON Dokument ein
void importSettings(Settings &settings, DynamicJsonDocument &doc) {
  // Get the root object in the document
  JsonObject root = doc.as<JsonObject>();

  // Numerische Daten
  getJsonInt (root, "mqttServerPort", settings.mqttServerPort, 1883);
  getJsonInt (root, "keypadDebounceTime", settings.keypadDebounceTime, 20);
  getJsonInt (root, "keypadRepeatDelay", settings.keypadRepeatDelay, 500);
  getJsonInt (root, "keypadRepeatInterval", settings.keypadRepeatInterval, 200);
  getJsonInt (root, "keypadRepeatMask", settings.keypadRepeatMask, KEYMASK_REPEAT_STD);
  getJsonInt (root, "keypadMultikeyTimeout", settings.keypadMultikeyTimeout, 2000);
  getJsonInt (root, "keypadMultikeyMask", settings.keypadMultikeyMask, KEYMASK_REPEAT_STD);
  getJsonInt (root, "keypadAPKeyTime", settings.keypadAPKeyTime, WIFI_AP_BUTTON_TIME);
  getJsonInt (root, "keypadAPKeyMask", settings.keypadAPKeyMask, WIFI_AP_KEYMASK);

  // Strings
  std::string clientName = "esp8266-";
  /*
  uint8_t mac[6];
  WiFi.macAddress(mac);
  clientName += macToStr(mac);
  */
  getJsonString (root, "wifiSSID", settings.wifiSSID, "Unknown");
  getJsonString (root, "wifiPassword", settings.wifiPassword, "Unknown");
  getJsonString (root, "mqttServer", settings.mqttServer, "127.0.0.1");
  getJsonString (root, "mqttUser", settings.mqttUser, "");
  getJsonString (root, "mqttPassword", settings.mqttPassword, "");
  getJsonString (root, "mqttClientName", settings.mqttClientName, clientName);
  getJsonString (root, "mqttPubTopic", settings.mqttPubTopic, "");
}

// Schreibt Einstellungen in JSON Dokument
void exportSettings(Settings &settings, DynamicJsonDocument &doc) {
  // Get the root object in the document
  JsonObject root = doc.as<JsonObject>();

  Serial.println ("Exportiere Einstellungen");
  // Numerische Daten
  doc["mqttServerPort"]=settings.mqttServerPort;
  doc["keypadDebounceTime"]=settings.keypadDebounceTime;
  doc["keypadRepeatDelay"]=settings.keypadRepeatDelay;
  doc["keypadRepeatInterval"]=settings.keypadRepeatInterval;
  doc["keypadMultikeyTimeout"]=settings.keypadMultikeyTimeout;
  doc["keypadAPKeyTime"]=settings.keypadAPKeyTime;
  //root["keypadRepeatMask"]=settings.keypadRepeatMask;
  //root["keypadMultikeyMask"]=settings.keypadMultikeyMask;

  // Numerische Daten als Hex
  char buf[50],buf2[50];
  itoa(settings.keypadMultikeyMask, buf, 16);
  sprintf(buf2,"0x%s",buf);
  doc["keypadMultikeyMask"]=buf2;
  itoa(settings.keypadRepeatMask, buf, 16);
  sprintf(buf2,"0x%s",buf);
  doc["keypadRepeatMask"]=buf2;
  itoa(settings.keypadAPKeyMask, buf, 16);
  sprintf(buf2,"0x%s",buf);
  doc["keypadAPKeyMask"]=buf2;

  // Strings
  doc["wifiSSID"]=settings.wifiSSID.c_str();
  doc["wifiPassword"]=settings.wifiPassword.c_str();
  doc["mqttServer"]=settings.mqttServer.c_str();
  doc["mqttUser"]=settings.mqttUser.c_str();
  doc["mqttPassword"]=settings.mqttPassword.c_str();
  doc["mqttClientName"]=settings.mqttClientName.c_str();
  doc["mqttPubTopic"]=settings.mqttPubTopic.c_str();

  serializeJsonPretty(doc, Serial);
}

// Default Einstellungen laden
void settingsDefault(Settings &settings) {
  // Allocate the document on the stack.
  // Don't forget to change the capacity to match your requirements.
  // Use arduinojson.org/assistant to compute the capacity.
  DynamicJsonDocument doc(JSON_BUFFER_SIZE_MAX_SETTINGS);

  // Default settings laden
  
  // Deserialize the JSON document
  //Serial.println (defaultSettings.c_str());
  DeserializationError error = deserializeJson(doc, defaultSettings);
  //serializeJsonPretty(doc, Serial);
  if (error) {
    Serial.println (defaultSettings.c_str());
    Serial.println(F("Failed reading default configuration"));
    return;
  }

  importSettings(settings, doc);
};

// Externe Einstellungen importieren
void importSettings(std::string & jsonSettings, Settings &settings) {
  // Allocate the document on the stack.
  // Don't forget to change the capacity to match your requirements.
  // Use arduinojson.org/assistant to compute the capacity.
  DynamicJsonDocument doc(JSON_BUFFER_SIZE_MAX_SETTINGS);

  // Default settings laden
  
  // Deserialize the JSON document
  //Serial.println (jsonSettings.c_str());
  DeserializationError error = deserializeJson(doc, jsonSettings);
  //serializeJsonPretty(doc, Serial);
  if (error) {
    Serial.println (jsonSettings.c_str());
    Serial.println(F("Failed reading extern configuration"));
    return;
  }

  importSettings(settings, doc);
}

// Loads the configuration from a file
void loadSettings(fs::FS &fs, const char * path, Settings &settings) {
  // Open file for reading
  File file = fs.open(path,"r");
  if(!file || file.isDirectory()){
      Serial.println("- failed to open settings file for reading");
      return;
  }

  // Import settings from file
  DynamicJsonDocument doc(JSON_BUFFER_SIZE_MAX_SETTINGS);
  
  // Deserialize the JSON document
  DeserializationError error = deserializeJson(doc, file);
  file.close();  //Schließen der Datei
  //serializeJsonPretty(doc, Serial);
  if (error) {
    Serial.println(F("Failed reading config file, using default configuration"));
    return;
  }
  Serial.println ("Settings JSON ok");
  //serializeJson(doc, Serial);
  
  importSettings(settings, doc);
  //return;

  // MQTT Topics neu setzen
  //if (mqttClient.connected()) { mqttsubscribe(settings); }
  // Close the file (File's destructor doesn't close the file)
  file.close();
}

void saveSettings(fs::FS &fs, const char * path, Settings &settings) {
  DynamicJsonDocument doc(JSON_BUFFER_SIZE_MAX_SETTINGS);

  // Export settings to JSON
  exportSettings(settings, doc);

  // Open file for writing
  File file = fs.open(path,"w");
  if(!file || file.isDirectory()){
      Serial.println("- failed to open settings file for writing");
      return;
  }

  // Deserialize the JSON document
  serializeJsonPretty(doc, file);
  file.close();  //Schließen der Datei

  serializeJsonPretty(doc, Serial);
}

void openSettingsWebConfig (Settings &settings, uint8_t * webConfigResult, int timeout) {
  _webConfigItems.clear();
  char buf[50];
  char bufx[50]="0x";
  _webConfigItems.push_back(WebConfigItem{.label="WiFi SSID", .name="wifiSSID", .placeholder="SSID", .value=settings.wifiSSID, .len=40, .regExPattern=""});
  _webConfigItems.push_back(WebConfigItem{.label="WiFi Password", .name="wifiPassword", .placeholder="Password", .value=settings.wifiPassword, .len=40, .regExPattern=""});

  _webConfigItems.push_back(WebConfigItem{.label="MQTT Server", .name="mqttServer", .placeholder="Server", .value=settings.mqttServer, .len=40, .regExPattern=""});
  itoa(settings.mqttServerPort,buf,10); _webConfigItems.push_back(WebConfigItem{.label="MQTT Server Port", .name="mqttServerPort", .placeholder="Portnumber", .value=std::string (buf), .len=5, .regExPattern=""});
  _webConfigItems.push_back(WebConfigItem{.label="MQTT User", .name="mqttUser", .placeholder="Username", .value=settings.mqttUser, .len=40, .regExPattern=""});
  _webConfigItems.push_back(WebConfigItem{.label="MQTT Password", .name="mqttPassword", .placeholder="Password", .value=settings.mqttPassword, .len=40, .regExPattern=""});
  _webConfigItems.push_back(WebConfigItem{.label="MQTT Client Name", .name="mqttClientName", .placeholder="Client Name", .value=settings.mqttClientName, .len=40, .regExPattern=""});
  _webConfigItems.push_back(WebConfigItem{.label="MQTT Pub Topic", .name="mqttPubTopic", .placeholder="Topic", .value=settings.mqttPubTopic, .len=80, .regExPattern=""});
  
  itoa(settings.keypadDebounceTime,buf,10); _webConfigItems.push_back(WebConfigItem{.label="Keypad Debounce Time", .name="keypadDebounceTime", .placeholder="Time/ms", .value=std::string (buf), .len=5, .regExPattern=""});
  itoa(settings.keypadRepeatDelay,buf,10); _webConfigItems.push_back(WebConfigItem{.label="Keypad Repeat Delay", .name="keypadRepeatDelay", .placeholder="Time/ms", .value=std::string (buf), .len=5, .regExPattern=""});
  itoa(settings.keypadRepeatInterval,buf,10); _webConfigItems.push_back(WebConfigItem{.label="Keypad Repeat Interval", .name="keypadRepeatInterval", .placeholder="Time/ms", .value=std::string (buf), .len=5, .regExPattern=""});
  itoa(settings.keypadRepeatMask,&bufx[2],16); _webConfigItems.push_back(WebConfigItem{.label="Keypad Repeat Keymask", .name="keypadRepeatMask", .placeholder="Keycode", .value=std::string (bufx), .len=6, .regExPattern=""});
  
  itoa(settings.keypadMultikeyTimeout,buf,10); _webConfigItems.push_back(WebConfigItem{.label="Multikey Input Timeout", .name="keypadMultikeyTimeout", .placeholder="Time/ms", .value=std::string (buf), .len=5, .regExPattern=""});
  itoa(settings.keypadMultikeyMask,&bufx[2],16); _webConfigItems.push_back(WebConfigItem{.label="Multikey Input Keymask", .name="keypadRepeatMask", .placeholder="Keycode", .value=std::string (bufx), .len=6, .regExPattern=""});

  itoa(settings.keypadAPKeyTime,buf,10); _webConfigItems.push_back(WebConfigItem{.label="AP Activation Keypressed Time", .name="keypadAPKeyTime", .placeholder="Time/ms", .value=std::string (buf), .len=5, .regExPattern=""});
  itoa(settings.keypadAPKeyMask,&bufx[2],16); _webConfigItems.push_back(WebConfigItem{.label="AP Activation Keymask", .name="keypadAPKeyMask", .placeholder="Keycode", .value=std::string (bufx), .len=6, .regExPattern=""});

  //webConfigPortal.setAP("WiFiKeypadConfig","password00");
  webConfigPortal.setTitle("WiFi Keypad Config Page");
  webConfigPortal.setItemStore(&_webConfigItems);
  webConfigPortal.setActionFlag (webConfigResult);
  webConfigPortal.setTimeout (timeout);
  webConfigPortal.startConfigPortal();
  //setupWeb(&_webConfigItems, webConfigResult, timeout);
}

std::string getJsonFromWebConfig () {
  DynamicJsonDocument doc(JSON_BUFFER_SIZE_MAX_SETTINGS);
  for (auto &item: _webConfigItems) {
    /*
    Serial.print (item.name.c_str());
    Serial.print (" - ");
    Serial.println (item.value.c_str());
    */
    //std::string index=item.name;
    doc[item.name.c_str()]=item.value.c_str();
  }
  char buf[JSON_BUFFER_SIZE_MAX_SETTINGS];
  serializeJson (doc, buf, JSON_BUFFER_SIZE_MAX_SETTINGS);
  return std::string(buf);
}

void updateSettingsWebPortal() {
  webConfigPortal.updateConfigPortal();
}
