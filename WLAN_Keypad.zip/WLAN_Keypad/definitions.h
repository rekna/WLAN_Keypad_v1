#include <vector>
#include <string>
#include <map>

// #define DEBUG_OUT

// Globale Deklarationen

#define JSON_BUFFER_SIZE_MAX          1024 
#define JSON_BUFFER_SIZE_MAX_SETTINGS 2048

#define INTERVAL_KEYINPUT             20
#define INTERVAL_MQTT_UPDATE          60000
#define INTERVAL_DISPLAY_REFRESH      100

#define TIMEOUT_WIFI_CONNECT          10000
#define TIMEOUT_WIFI_CONFIGURATION    240
#define TIMEOUT_DISPLAY_OFF           300000

#define KEYPAD_MCP23017               // Uncomment, when Keypad connected to MCP23017 IC
#define KEYPAD_DIRECT                 // Uncomment, when Keypad connected directly to uC

#if defined(KEYPAD_MCP23017)
  #define KEYPAD_I2C_ADDRESS          0x20
#endif

#define DISPLAY_OLED_SSD1306          // Uncomment, when SSD1306 Display is connected
#ifdef DISPLAY_OLED_SSD1306
  #define DISPLAY_SIZE_X              128
  #define DISPLAY_SIZE_Y              64
  #define DISPLAY_ORITENTATION        0
  #define OLED_RESET                  -1 // Reset pin # (or -1 if sharing Arduino reset pin)
  #define DISPLAY_I2C_ADR             0x3C
#endif

// Sanity for defines
#if defined (KEYPAD_MCP23017)
  #undef KEYPAD_DIRECT
#endif

#if defined (KEYPAD_MCP23017) || defined (DISPLAY_OLED_SSD1306)
  #define I2C_MASTER_ADDRESS        0x10
  #define I2C_SDA_PIN               4
  #define I2C_SCL_PIN               5
  #define I2C_USE
#endif

#ifdef KEYPAD_DIRECT
  extern std::vector<int> rowPins;
  extern std::vector<int> colPins;
#endif

// Tastencodes 

#define KEYCODE_NONE      0x0000
#define KEYCODE_UP        0x0001
#define KEYCODE_1         0x0002
#define KEYCODE_4         0x0004
#define KEYCODE_7         0x0008
#define KEYCODE_0         0x0010
#define KEYCODE_2         0x0020
#define KEYCODE_5         0x0040
#define KEYCODE_8         0x0080
#define KEYCODE_SELECT    0x0100
#define KEYCODE_3         0x0200
#define KEYCODE_6         0x0400
#define KEYCODE_9         0x0800
#define KEYCODE_DOWN      0x1000
#define KEYCODE_CANCEL    0x2000
#define KEYCODE_CLEAR     0x4000
#define KEYCODE_ENTER     0x8000

#define KEYMASK_REPEAT_STD      (KEYCODE_0|KEYCODE_1|KEYCODE_2|KEYCODE_3|KEYCODE_4|KEYCODE_5|KEYCODE_6|KEYCODE_7|KEYCODE_8|KEYCODE_9)

#define WIFI_AP_KEYMASK       KEYCODE_CANCEL
#define WIFI_AP_PIN           0
#define WIFI_AP_BUTTON_TIME   3000

extern std::string defaultSettings;
extern const std::string charMap;
extern const std::string charMapSorted;
extern const int charMapSortedIndex[];
extern const std::string IPDELIMSUBNET;
extern const std::string IPDELIM;
extern const std::string configfilename;
extern const char CONFIG_AP_SSID [];
extern const char CONFIG_AP_PASSWORD [];
extern uint8_t webConfigResult;
extern std::string _regExTimeMS;
extern std::string _regExTimeDebounceMS;
extern std::string _regExPortNumber;
extern std::string _regExMQTTTopic;
