#include "definitions.h"

/*
const char CONFIG_AP_SSID [] = "WiFi Keyboard";
const char CONFIG_AP_PASSWORD [] = "password00";
*/

std::string _regExTimeMS         = "[0-9]{1,5}";
std::string _regExTimeDebounceMS = "[0-9]{1,4}";
std::string _regExPortNumber     = "([0-5][0-9]{0,4}\s|[6][0-4][0-9]{3}\s|[6][5][0-4]{3}\s|[6][5][5][0-2]{2}\s|[6][5][5][3][0-5]{1}\s)";
std::string _regExMQTTTopic      = "^[^\/][\d\w\/]*";

std::string defaultSettings= \
          "{\"wifiSSID\":\"?\", \
          \"wifiPassword\":\"?\", \
          \"mqttServer\":\"?\", \
          \"mqttServerPort\":1883, \
          \"mqttClientName\":\"?\", \
          \"mqttUser\":\"?\", \
          \"mqttPassword\":\"?\", \
          \"mqttPubTopic\":\"?\", \
          \"keypadDebounceTime\":20, \
          \"keypadRepeatDelay\":500, \
          \"keypadRepeatInterval\":200, \
          \"keypadRepeatMask\":\"0xefe\", \
          \"keypadMultikeyMask\":\"0xefe\", \
          \"keypadAPKeyMask\":\"0x2000\", \
          \"keypadAPKeyTime\":\"2500\", \
          \"keypadMultikeyTimeout\":2000}";

//          \"keypadRepeatMask\":3838, \

#ifdef KEYPAD_DIRECT
  std::vector<int> rowPins={3,0,2,4};     // Input, Pull-Up
  std::vector<int> colPins={14,12,13,5};  // Output, Active LOW; Sonst Input, Pull-Up
#endif

int ledToggleTimeOk[LED_TOGGLE_DEF_MAX] = {50,1950,50,1950};
int ledToggleTimeAP[LED_TOGGLE_DEF_MAX] = {2000,333,333,333};
int ledToggleTimeWLAN[LED_TOGGLE_DEF_MAX] = {50,50,50,50};
int ledToggleTimeMQTT[LED_TOGGLE_DEF_MAX] = {500,500,500,500};

const std::string charMap= "u1470258s369dxce";

// Index der sortierten charMap (für kontrollierte Buchstabenangabe per MQTT)
// Position     Inhalt
// 0 - 9        Ziffern
// 10 - 15      Sondertasten

const std::string charMapSorted= "0123456789udsxce";
const int charMapSortedIndex[]={
   KEYCODE_0,KEYCODE_1,KEYCODE_2,KEYCODE_3,KEYCODE_4,KEYCODE_5,KEYCODE_6,KEYCODE_7,
   KEYCODE_8,KEYCODE_9,KEYCODE_UP,KEYCODE_DOWN,KEYCODE_SELECT,KEYCODE_CANCEL,KEYCODE_CLEAR,KEYCODE_ENTER
};

const std::string IPDELIMSUBNET="/";
const std::string IPDELIM=".";

std::string const configfilename = "/config.txt";

uint8_t webConfigResult=0;
