#pragma once

#include <ESP8266WiFi.h>
#include <WiFiClient.h>
#include <ESP8266WebServer.h>
#include <ESP8266mDNS.h>

class WebConfigItem {
public:
  std::string label;
  std::string name;
  std::string placeholder;
  std::string value;
  int len;
  std::string regExPattern;
};

class WebConfigPortal {
  private:
    std::string _apSSID;
    std::string _apPassword;
    std::string _htmlConfigPage;
    std::string _htmlTitle;
    std::string _htmlMessage;
    std::vector<WebConfigItem> * _itemStore;
    uint8_t * _actionResult;
    uint32_t _webConfigStartTime;
    int _webConfigTimeout;
    IPAddress _ip,_gw,_nm,_dns1,_dns2;
    
    void myReplace(std::string & myString, const std::string & searchPattern, const std::string & replaceStr);
    std::string generateHtmlInputField (const std::string & inputLabel, const std::string & inputName, const std::string & inputPlaceholder, const std::string & inputValue, const int & len, const std::string regEx);
    std::string buildWebForm();
    int findWebItemIndex (std::string itemName);
  public:    
    WebConfigPortal();
    void handleRoot ();
    void handleAction ();
    void setAP(std::string ssid, std::string password="");
    void setTitle (std::string newTitle);
    void setItemStore (std::vector<WebConfigItem> * itemStore);
    void setActionFlag (uint8_t * actionFlag);
    void setTimeout (int timeout=-1);
    void startConfigPortal();
    void stopConfigPortal();
    void updateConfigPortal();
    
};

// {label="label"; name="name"; placeholder="placeholder"; value="value"; len=10}

/*
void setupWeb(std::vector<WebConfigItem_t> * itemStore, uint8_t * actionFlag, int timeout=-1);
void stopWebserver ();
void updateWebserver();
*/

//void handleRoot();
/*
void returnFail(String msg);
void handleSubmit();
void returnOK();
void handleLEDon();
void handleLEDoff();
void handleNotFound();
*/
